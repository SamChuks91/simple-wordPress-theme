<!--side bar-->
	<div class="col-md-4">
		
		<?php dynamic_sidebar('sidebar1'); ?>
		
	</div>